package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Education;
import com.cg.bean.Personal;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EducationStepDefinition {
	
	private WebDriver driver;
	private Education education;
	
	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver", "driver/chromedriver.exe");		
	}
	
//	@After
//	public void destroy() {
//		driver.quit();
//	}	
	
	
	@Given("^User is on Educational Details page$")
	public void user_is_on_Educational_Details_page() throws Throwable {
		driver = new ChromeDriver();
		driver.get("C:\\Users\\pyeole\\SpringWorkspace\\bdd-demoCase\\html\\EducationalDetails.html");
		education = new Education();
		PageFactory.initElements(driver, education);
		
	}
	
	@Then("^Validate Educational Detail page$")
	public void validate_Educational_Detail_page() throws Throwable {
		String str = driver.getTitle();
		if(str.equals("Educational Details"));
		System.out.println("You are on the correct page");
		driver.close();
	}

	@When("^user enetrs invalid Graduation$")
	public void user_enetrs_invalid_Graduation() throws Throwable {
		education.clickGraduation(0);
	}

	@Then("^display 'Please fill the Graduation '$")
	public void display_Please_fill_the_Graduation() throws Throwable {
		education.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enetrs invalid percentage$")
	public void user_enetrs_invalid_percentage() throws Throwable {
		education.clickGraduation(2);
		education.setPercentage("");
	}

	@Then("^display 'Please fill the percentage'$")
	public void display_Please_fill_the_percentage() throws Throwable {
		education.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enetrs invalid passingYear$")
	public void user_enetrs_invalid_passingYear() throws Throwable {
		education.clickGraduation(2);
		education.setPercentage("70");
		education.setpassingYear("");
	}

	@Then("^display 'Please fill the Passing Year'$")
	public void display_Please_fill_the_Passing_Year() throws Throwable {
		education.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enetrs invalid Project Name$")
	public void user_enetrs_invalid_Project_Name() throws Throwable {
		education.clickGraduation(2);
		education.setPercentage("70");
		education.setpassingYear("2018");
		education.setprojectName("");
	}

	@Then("^display 'Please fill the Project Name'$")
	public void display_Please_fill_the_Project_Name() throws Throwable {
		education.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enetrs invalid Technologies$")
	public void user_enetrs_invalid_Technologies() throws Throwable {
		education.clickGraduation(2);
		education.setPercentage("70");
		education.setpassingYear("2018");
		education.setprojectName("MachineLearning");
		education.clickTechnology(0);
	}

	@Then("^display 'Please fill the Technologies'$")
	public void display_Please_fill_the_Technologies() throws Throwable {
		education.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enetrs invalid Others$")
	public void user_enetrs_invalid_Others() throws Throwable {
		education.clickGraduation(2);
		education.setPercentage("70");
		education.setpassingYear("2018");
		education.setprojectName("MachineLearning");
		education.clickTechnology(3);
	}

	@Then("^display 'Please fill the Others'$")
	public void display_Please_fill_the_Others() throws Throwable {
		education.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enters all valid details$")
	public void user_enters_all_valid_details() throws Throwable {
		education.clickGraduation(2);
		education.setPercentage("70");
		education.setpassingYear("2018");
		education.setprojectName("MachineLearning");
		education.clickTechnology(3);
		education.setOtherTech("spring");
		education.clickNext();
	}

	@Then("^display 'Educational details are validated'$")
	public void display_Educational_details_are_validated() throws Throwable {
	//	education.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}
}
