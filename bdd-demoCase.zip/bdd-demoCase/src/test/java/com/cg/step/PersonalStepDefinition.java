package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Personal;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalStepDefinition {
	
	private WebDriver driver;
	private Personal person;
	
	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver", "driver/chromedriver.exe");
		//driver = new ChromeDriver();
	}
		
	@Given("^User is on personal details page$")
	public void user_is_on_personal_details_page() throws Throwable {
		driver = new ChromeDriver();
		driver.get("C:\\Users\\pyeole\\SpringWorkspace\\bdd-demoCase\\html\\PersonalDetails.html");
		person = new Personal();
		PageFactory.initElements(driver, person);
	
	}

	@Then("^Validate personal details page$")
	public void validate_personal_details_page() throws Throwable {
		String str = driver.getTitle();
		if(str.equals("Personal Details"));
		System.out.println("You are on the correct page");
		driver.close();
	}

	@When("^User enters first name$")
	public void user_enters_first_name() throws Throwable {
		person.setFirstName("ra");
	}

	@Then("^Validate first name$")
	public void validate_first_name() throws Throwable {
		person.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User enters last name$")
	public void user_enters_last_name() throws Throwable {
		person.setFirstName("Pranita");
		person.setLastName("to");
	}

	@Then("^Validate last name$")
	public void validate_last_name() throws Throwable {
		person.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User enters email$")
	public void user_enters_email() throws Throwable {
		person.setFirstName("Pranita");
		person.setLastName("Yeole");
		person.setEmail("gdtd@gujgtu");
	}

	@Then("^Validate email$")
	public void validate_email() throws Throwable {
		person.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}
	
	@When("^User enters contact number with empty$")
	public void user_enters_contact_number_with_empty() throws Throwable {
		person.setFirstName("Pranita");
		person.setLastName("Yeole");
		person.setEmail("pra.kyeole@gmail.com");
		person.setContact("");
	
	}

	@Then("^Validate contact number$")
	public void validate_contact_number() throws Throwable {
		person.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User enters contact number not start with (\\d+)/(\\d+)/(\\d+)$")
	public void user_enters_contact_number_not_start_with(int arg1, int arg2, int arg3) throws Throwable {
		person.setFirstName("Pranita");
		person.setLastName("Yeole");
		person.setEmail("pra.kyeole@gmail.com");
		person.setContact("1234567890");
	}

	@Then("^Validate contact number(\\d+)$")
	public void validate_contact_number(int arg1) throws Throwable {
		person.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User enters address$")
	public void user_enters_address() throws Throwable {
		person.setFirstName("Pranita");
		person.setLastName("Yeole");
		person.setEmail("pra.kyeole@gmail.com");
		person.setContact("7276240897");
		person.setAddress1("azxqes");
	}

	@Then("^Validate address$")
	public void validate_address() throws Throwable {
		person.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}
	
	@When("^User enters address(\\d+)$")
	public void user_enters_address(int arg1) throws Throwable {
		person.setFirstName("Pranita");
		person.setLastName("Yeole");
		person.setEmail("pra.kyeole@gmail.com");
		person.setContact("7276240897");
		person.setAddress1("Airoli");
		person.setAddress2("5487971");
	}

	@Then("^Validate address(\\d+)$")
	public void validate_address(int arg1) throws Throwable {
		person.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User selects city$")
	public void user_selects_city() throws Throwable {
		person.setFirstName("Pranita");
		person.setLastName("Yeole");
		person.setEmail("pra.kyeole@gmail.com");
		person.setContact("7276240897");
		person.setAddress1("Airoli");
		person.setAddress2("Mumbai");
		person.clickCity(0);
	}

	@Then("^Validate city$")
	public void validate_city() throws Throwable {
		person.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User selects state$")
	public void user_selects_state() throws Throwable {
		person.setFirstName("Pranita");
		person.setLastName("Yeole");
		person.setEmail("pra.kyeole@gmail.com");
		person.setContact("7276240897");
		person.setAddress1("Airoli");
		person.setAddress2("Mumbai");
		person.clickCity(1);
	}

	@Then("^Validate state$")
	public void validate_state() throws Throwable {
		person.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User clicks on Next button$")
	public void user_clicks_on_Next_button() throws Throwable {
		person.setFirstName("Pranita");
		person.setLastName("Yeole");
		person.setEmail("pra.kyeole@gmail.com");
		person.setContact("7276240897");
		person.setAddress1("Airoli");
		person.setAddress2("Mumbai");
		person.clickCity(1);
		person.clickState(1);
	}

	@Then("^Show successful alert$")
	public void show_successful_alert() throws Throwable {
		person.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}
}
